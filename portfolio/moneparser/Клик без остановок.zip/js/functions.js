var isMobile = navigator.userAgent.match(/(iPhone|iPod|iPad|BlackBerry|Android)/i) != null;
var map = document.getElementById('map');
var areas = new Array();
var fields = new Array();
var polygon;
if (isMobile) {
    eventpress = 'touchstart';
    eventunpress = 'touchend'
    eventmove = 'touchmove'
} else {
    eventpress = 'mousedown';
    eventunpress = 'mouseup'
    eventmove = 'mousemove'
}


$(function () {

    var user_action = false;
    var cursor_interval = 5000;

    var cursorPlay = setInterval(function () {
        cursorShow();
    }, cursor_interval);

    // setTimeout(function () {
    //     cursorShow();
    // }, cursor_interval);
    //
    // setTimeout(function () {
    //     cursorShow();
    // }, cursor_interval * 2.5);
    //
    // setTimeout(function () {
    //     cursorShow();
    // }, cursor_interval * 4);

    function cursorShow() {
        var cursor_cell_eq = Math.floor(Math.random() * 24);
        var $cursor_cell = $('.money:not(.bomb)').eq(cursor_cell_eq);
        if (user_action == false) {
            $cursor_cell.addClass('cursor');
        }

        setTimeout(function () {
            $cursor_cell.removeClass('cursor');
            if (user_action == false) {
                $cursor_cell.addClass('active');
                $(".field-block").addClass("active");
                $("#take-money span").html($("#take-money span").html() * 1 + 30);

                setTimeout(function () {
                    if (user_action == false) {
                        $("#modal").removeClass("active");
                        $("#take-money span").html(0);
                        $(".money").removeClass('active');
                        $(".field-block").removeClass('active');
                    }
                }, cursor_interval / 2);
            }
        }, cursor_interval / 2);


    }


    $(window).resize(function () {
        $(".main-block").css("min-height", $("#content-size").height());
    });
    $(window).resize();

    $('.money').removeClass('bomb');
    $('.money').eq(Math.floor(Math.random() * ($('.money').length - 0.4))).addClass('bomb');

    $(".money").on("click", function () {
        clearInterval(cursorPlay);
        $(".money").removeClass('cursor');
        user_action = true;
        if (!$(this).hasClass("active")) {
            if ($(".money.active").length == 0) {
                $("#take-money span").html(0);
            }
            $(this).addClass("active");
            yaCounter48891506.reachGoal('cell');
            if (!$(this).hasClass("bomb")) {
                if (!$(".field-block").hasClass("active")) {
                    $(".field-block").addClass("active");
                }
                $("#take-money span").html($("#take-money span").html() * 1 + 30);
            } else {
                $(".balance span").html($(".balance span").html() * 1 - 30);
                $(".modal").hide();
                $(".modal.bomb").show();
                $("#modal").addClass("active");
                $(".field-block").removeClass('active');
                $("#take-money span").html(0);
            }
        }
    });

    $("#take-money").on("click", function () {
        $(".balance").slideDown(300);
        $(".balance span").html($(".balance span").html() * 1 + $("#take-money span").html() * 1);
        $(".money").removeClass('active');
        $(".field-block").removeClass('active');
        yaCounter48891506.reachGoal('zabrat');
    });
    $(".add-btn").on("click", function () {
        $(".modal").hide();
        $(".modal.add-sum").show();
        $("#modal").addClass("active");
        yaCounter48891506.reachGoal('popolnit1');
        return false;
    });
    $(".take-btn").on("click", function () {
        $(".modal").hide();
        $(".modal.in-demo").show();
        $("#modal").addClass("active");
        yaCounter48891506.reachGoal('vivesti1');
        return false;
    });
    $(".modal.add-sum form").on("submit", function (e) {
        e.preventDefault();

        if ($(this).find("input[name='sum']").val !== "") {
            yaCounter48891506.reachGoal('popollnitmoney');
            $(".modal").hide();
            $(".modal.payment-method").show();
            $("#modal").addClass("active");
        }
    });
    $(".modal.payment-method .modal-btn").on("click", function (e) {
        e.preventDefault();

        var $this = $(this);
        $.ajax({
            url: "mail/mail.php",
            method: "POST",
            data: {
                'sum': $(".add-sum form input[name='sum']").val(),
                'method': $this.text(),
                'form-name': 'form-add-sum'
            },
            dataType: "json",
            success: function (response) {

            }
        });
    });

    $(".modal-btn").on("click", function () {
        if ($(this).hasClass("to-why")) {
            $(".modal").hide();
            $(".modal.why").show();
        } else if ($(this).hasClass("to-add")) {
            $(".modal").hide();
            $(".modal.add-sum").show();
        } else if ($(this).closest(".modal.add-sum").length) {

        } else {
            $(".close-modal").click();
        }
    });

    $(".close-modal").on("click", function () {
        $("#modal").removeClass("active");
        $("#take-money span").html(0);
        $(".money").removeClass('active');
        $('.money').removeClass('bomb');
        $('.money').eq(Math.floor(Math.random() * ($('.money').length - 0.4))).addClass('bomb');
        $(".field-block").removeClass('active');
    });

    var rnd_index = 0;
    setInterval(function () {
        $(".left-block-lines").hide();
        rnd_index++;
        if (rnd_index == $(".left-block-lines").length) {
            rnd_index = 0;
        }
        rnd_sum = Math.ceil(Math.random() * 10000);
        var sum1 = $(".left-block-header-title").eq(0).find('span').html();
        var sum2 = $(".left-block-header-title").eq(1).find('span').html();
        sum1 = sum1.split(' ').join('') * 1 + rnd_sum;
        sum2 = sum2.split(' ').join('') * 1 + rnd_sum;
        sum1 = addSpaces(sum1);
        sum2 = addSpaces(sum2);
        $(".left-block-header-title").eq(0).find('span').html(sum1);
        $(".left-block-header-title").eq(1).find('span').html(sum2);
        $(".left-block-lines").eq(rnd_index).show();
    }, 1000);

})

function addSpaces(nStr) {
    nStr += '';
    x = nStr.split('.');
    x1 = x[0];
    x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1)) {
        x1 = x1.replace(rgx, '$1' + ' ' + '$2');
    }
    return x1 + x2;
}